<?php 
function hitungDeterminan()


echo "<table style:3px; border";


?>