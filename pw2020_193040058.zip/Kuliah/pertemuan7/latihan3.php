<?php
// SUPERGLOBALS
// Variabel bawaan php yang bisa kita gunakan
// bentuknya ARRAY ASSOCIATIVE 

// $_GET
// bisa mengambil data dari URL
print_r($_GET);
echo '<hr>';

echo "<h1> Selamat Datang  $_GET </h1>";

// $_POST
// $_SESSION
// $_COOKIE
// $_SERVER


?>