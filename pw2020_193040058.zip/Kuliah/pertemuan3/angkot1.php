<?php

$i = 1;
while ($i <= 10) {
    echo "Angkot No. $i beroprasi dengan baik. <br>";
    $i++;
}

?>