<?php

$i = 1;
while ($i <= 6) {
    echo "Angkot No. $i beroprasi dengan baik. <br>";
    $i++;
}

for ($ii =7; $ii <= 10; $ii++) {
    echo "Angkot No. $ii Sedang tidak beroprasi. <br>";
}
?>