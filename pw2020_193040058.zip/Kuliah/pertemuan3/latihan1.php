<?php
// Pengulangan
// While
$i = 10; // Nilai Awal
while ($i >= 1) { //Kondisi Terminasi
    // echo 'Hello World ' . $i . ' kali <br>';
    echo "Hello World $i kali <br>";
    $i--; // increment / decrement
} echo "selesai";


?>